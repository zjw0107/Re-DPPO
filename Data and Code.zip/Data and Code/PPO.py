import torch
import torch.nn as nn
from torch.distributions import Categorical
import numpy as np
from osgeo import gdal
import os
import pandas as pd

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class GridEnvironment:
    def __init__(self, raster_path, start, goal):
        self.raster_path = raster_path
        self.grid = self._load_raster()
        self.start = start
        self.goal = goal
        self.current_position = None
        self.done = False
        self.visited_positions = set()
        self.original_grid = self.grid.copy()

    def _load_raster(self):
        dataset = gdal.Open(self.raster_path)
        band = dataset.GetRasterBand(1)
        return band.ReadAsArray()

    def reset(self, fixed_start_goal=False):

        self.grid = self.original_grid.copy()


        num_obstacles = np.random.randint(0, 101)
        for _ in range(num_obstacles):
            while True:
                x = np.random.randint(0, self.grid.shape[0])
                y = np.random.randint(0, self.grid.shape[1])

                if (x, y) != self.start and (x, y) != self.goal and self.grid[x, y] != -100:
                    self.grid[x, y] = -100
                    break

        if fixed_start_goal:
            self.start = (0, 0)
            self.goal = (29, 29)
        else:
            while True:
                self.start = (np.random.randint(0, self.grid.shape[0]), np.random.randint(0, self.grid.shape[1]))
                self.goal = (np.random.randint(0, self.grid.shape[0]), np.random.randint(0, self.grid.shape[1]))
                if (self.grid[self.start] != -100 and self.grid[self.goal] != -100 and self.start != self.goal):
                    break
        self.current_position = self.start
        self.done = False
        self.visited_positions.clear()
        self.visited_positions.add(self.start)
        return self._get_state()

    def _get_state(self):
        x, y = self.current_position

        goal_rel_x = self.goal[0] - x
        goal_rel_y = self.goal[1] - y

        goal_x = self.goal[0]
        goal_y = self.goal[1]

        neighbor_states = []
        for dx, dy in [(-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1)]:
            x_new, y_new = x + dx, y + dy
            if 0 <= x_new < self.grid.shape[0] and 0 <= y_new < self.grid.shape[1]:
                if self.grid[x_new][y_new] == -100:
                    distance = np.sqrt((x_new - x) ** 2 + (y_new - y) ** 2)
                    neighbor_states.append(distance)
                else:
                    neighbor_states.append(100)
            else:
                neighbor_states.append(-100)
        return np.array([goal_rel_x, goal_rel_y, goal_x, goal_y] + neighbor_states, dtype=np.float32)

    def step(self, action):
        direction_map = [(-1, 0), (-1, 1), (0, 1), (1, 1),
                         (1, 0), (1, -1), (0, -1), (-1, -1)]
        dx, dy = direction_map[action]
        x, y = self.current_position
        new_position = (x + dx, y + dy)
        reward = -1
        if 0 <= new_position[0] < self.grid.shape[0] and 0 <= new_position[1] < self.grid.shape[1]:
            self.current_position = new_position
            grid_value = self.grid[self.current_position]
            if grid_value == -100:
                reward += -10
            else:
                reward += grid_value * 0.1
            if new_position in self.visited_positions:
                reward -= 7
            else:
                self.visited_positions.add(new_position)
        else:
            reward += -10
        old_distance = np.sqrt((self.goal[0] - x) ** 2 + (self.goal[1] - y) ** 2)
        new_distance = np.sqrt((self.goal[0] - self.current_position[0]) ** 2 + (self.goal[1] - self.current_position[1]) ** 2)
        reward += -1 if new_distance > old_distance else 0
        if self.current_position == self.goal:
            self.done = True
            reward += 15
        return self._get_state(), reward, self.done, {}

    def render(self):
        grid_copy = self.grid.copy()
        x, y = self.current_position
        grid_copy[x, y] = -999
        print(grid_copy)


class Memory:
    def __init__(self):
        self.actions = []
        self.states = []
        self.logprobs = []
        self.rewards = []
        self.is_terminals = []

    def clear_memory(self):

        del self.actions[:]
        del self.states[:]
        del self.logprobs[:]
        del self.rewards[:]
        del self.is_terminals[:]


class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim, n_latent_var):
        super(ActorCritic, self).__init__()
        self.action_layer = nn.Sequential(
            nn.Linear(state_dim, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, action_dim),
            nn.Softmax(dim=-1)
        )
        self.value_layer = nn.Sequential(
            nn.Linear(state_dim, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, 1)
        )

    def forward(self):
        raise NotImplementedError

    def act(self, state, memory):

        state = torch.from_numpy(state).float().to(device)
        action_probs = self.action_layer(state)
        dist = Categorical(action_probs)
        action = dist.sample()

        memory.states.append(state)
        memory.actions.append(action)
        memory.logprobs.append(dist.log_prob(action))

        return action.item()

    def evaluate(self, state, action):

        action_probs = self.action_layer(state)
        dist = Categorical(action_probs)

        action_logprobs = dist.log_prob(action)
        dist_entropy = dist.entropy()
        state_value = self.value_layer(state)

        return action_logprobs, torch.squeeze(state_value), dist_entropy


class PPO:
    def __init__(self, state_dim, action_dim, n_latent_var, lr, betas, gamma, K_epochs, eps_clip):
        self.lr = lr
        self.betas = betas
        self.gamma = gamma
        self.eps_clip = eps_clip
        self.K_epochs = K_epochs

        self.policy = ActorCritic(state_dim, action_dim, n_latent_var).to(device)
        self.optimizer = torch.optim.Adam(self.policy.parameters(), lr=lr, betas=betas)
        self.policy_old = ActorCritic(state_dim, action_dim, n_latent_var).to(device)
        self.policy_old.load_state_dict(self.policy.state_dict())

        self.MseLoss = nn.MSELoss()

    def update(self, memory):

        rewards = []
        discounted_reward = 0
        for reward, is_terminal in zip(reversed(memory.rewards), reversed(memory.is_terminals)):
            if is_terminal:
                discounted_reward = 0
            discounted_reward = reward + (self.gamma * discounted_reward)
            rewards.insert(0, discounted_reward)
        rewards = torch.tensor(rewards, dtype=torch.float32).to(device)
        mean_reward = rewards.mean()
        std_reward = rewards.std()
        if std_reward > 0:
            rewards = (rewards - mean_reward) / (std_reward + 1e-5)
        else:
            rewards = rewards - mean_reward

        old_states = torch.stack(memory.states).to(device).detach()
        old_actions = torch.stack(memory.actions).to(device).detach()
        old_logprobs = torch.stack(memory.logprobs).to(device).detach()

        for _ in range(self.K_epochs):
            logprobs, state_values, dist_entropy = self.policy.evaluate(old_states, old_actions)

            ratios = torch.exp(logprobs - old_logprobs.detach())
            advantages = rewards - state_values.detach()

            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
            loss = -torch.min(surr1, surr2).mean() + 0.5 * self.MseLoss(state_values,
                                                                        rewards) - 0.05 * dist_entropy.mean()
            self.optimizer.zero_grad()
            loss.mean().backward()
            torch.nn.utils.clip_grad_norm_(self.policy.parameters(), max_norm=1.0)
            self.optimizer.step()
        self.policy_old.load_state_dict(self.policy.state_dict())


def main():
    raster_path = "128.tif"
    start = (10, 5)
    goal = (120, 120)
    env = GridEnvironment(raster_path, start, goal)

    state_dim = 12
    action_dim = 8
    n_latent_var = 128

    memory = Memory()
    ppo = PPO(state_dim, action_dim, n_latent_var, lr=0.0001, betas=(0.9, 0.999),
              gamma=0.99, K_epochs=4, eps_clip=0.15)

    max_episodes = 30000
    max_timesteps = 500


    checkpoint_path = ""
    if os.path.exists(checkpoint_path):
        ppo.policy.load_state_dict(torch.load(checkpoint_path))
        ppo.policy_old.load_state_dict(ppo.policy.state_dict())
        print(f"Loaded model from {checkpoint_path}")
    else:
        print("No checkpoint found, starting from scratch.")


    rewards_df = pd.DataFrame(columns=["Episode", "Reward"])

    start_episode = 1

    for i_episode in range(start_episode, max_episodes + 1):
        if i_episode <= 1:
            state = env.reset(fixed_start_goal=True)
        else:
            state = env.reset(fixed_start_goal=False)
        total_reward = 0
        for t in range(max_timesteps):

            action = ppo.policy_old.act(state, memory)
            state, reward, done, _ = env.step(action)

            total_reward += reward

            memory.rewards.append(reward)
            memory.is_terminals.append(done)
            if done:
                break

        ppo.update(memory)
        memory.clear_memory()


        print(f"Episode {i_episode} completed. Total Reward: {total_reward}")

        new_row = pd.DataFrame({"Episode": [i_episode], "Reward": [total_reward]})
        rewards_df = pd.concat([rewards_df, new_row], ignore_index=True)

        if i_episode % 2000 == 0:
            torch.save(ppo.policy.state_dict(), f"ppo_model_episode_{i_episode}.pth")
            rewards_df.to_excel(f"ppo_{i_episode}.xlsx", index=False)  # 保存奖励数据到 Excel



    print("\n" + "=" * 50)

    print("=" * 50)
print("Training finished!")

if __name__ == "__main__":
    main()


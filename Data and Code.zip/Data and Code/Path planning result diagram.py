import torch
import torch.nn as nn
import numpy as np
from torch.distributions import Categorical
import matplotlib.pyplot as plt
from osgeo import gdal
import math
from scipy.special import comb

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def bresenham_line(p0, p1):

    x0, y0 = p0;
    x1, y1 = p1
    points = []
    dx, dy = abs(x1 - x0), abs(y1 - y0)
    x, y = x0, y0
    sx = 1 if x1 > x0 else -1
    sy = 1 if y1 > y0 else -1
    if dx > dy:
        err = dx / 2
        while x != x1:
            points.append((x, y))
            err -= dy
            if err < 0:
                y += sy
                err += dx
            x += sx
    else:
        err = dy / 2
        while y != y1:
            points.append((x, y))
            err -= dx
            if err < 0:
                x += sx
                err += dy
            y += sy
    points.append((x1, y1))
    return points


def check_line_clear(p0, p1, grid, bad_values={-10, -50, -100}):

    for x, y in bresenham_line(p0, p1):
        if grid[x, y] in bad_values:
            return False
    return True


def extract_key_points(path, grid):

    if len(path) <= 2:
        return path

    key_points = [path[0]]

    for i in range(1, len(path) - 1):
        prev = path[i - 1]
        curr = path[i]
        next_p = path[i + 1]

        if (grid[curr] != grid[prev]) or (grid[curr] != grid[next_p]):
            key_points.append(curr)

    key_points.append(path[-1])
    return key_points


def cubic_bezier(p0, p1, p2, p3, num_points=30):

    t = np.linspace(0, 1, num_points)
    t2 = t * t
    t3 = t2 * t
    mt = 1 - t
    mt2 = mt * mt
    mt3 = mt2 * mt

    curve = np.outer(mt3, p0) + \
            3 * np.outer(mt2 * t, p1) + \
            3 * np.outer(mt * t2, p2) + \
            np.outer(t3, p3)
    return curve


def smooth_with_cubic_bezier(path, grid):

    if len(path) <= 4:
        return path

    key_points = extract_key_points(path, grid)
    if len(key_points) < 4:
        return path


    smoothed = []
    for i in range(0, len(key_points) - 3, 3):
        p0 = np.array(key_points[i])
        p1 = np.array(key_points[i + 1])
        p2 = np.array(key_points[i + 2])
        p3 = np.array(key_points[i + 3])

        segment_length = math.hypot(p3[0] - p0[0], p3[1] - p0[1])
        num_points = max(10, min(50, int(segment_length / 5)))
        curve = cubic_bezier(p0, p1, p2, p3, num_points)
        curve = [(int(round(x)), int(round(y))) for x, y in curve]

        valid_segment = [tuple(p0)]
        for j in range(1, len(curve)):
            if check_line_clear(valid_segment[-1], curve[j], grid):
                valid_segment.append(curve[j])
            else:

                break

        smoothed.extend(valid_segment)


    if len(key_points) % 3 != 0:
        remaining_points = key_points[-(len(key_points) % 3 + 1):]
        if len(remaining_points) >= 2:
            for x, y in bresenham_line(remaining_points[-2], remaining_points[-1]):
                if check_line_clear(smoothed[-1], (x, y), grid):
                    smoothed.append((x, y))


    smoothed = list(dict.fromkeys(smoothed))
    if len(smoothed) == 0 or smoothed[-1] != path[-1]:
        smoothed.append(path[-1])

    return smoothed


class GridEnvironment:
    def __init__(self, raster_path, start, goal):
        self.raster_path = raster_path
        self.grid = self._load_raster()
        self.start = start
        self.goal = goal
        self.current_position = None
        self.done = False
        self.visited_positions = set()
        self.original_grid = self.grid.copy()

    def _load_raster(self):
        ds = gdal.Open(self.raster_path)
        return ds.GetRasterBand(1).ReadAsArray()


    def reset(self, start=None, goal=None, fixed_start_goal=False):
        self.grid = self.original_grid.copy()

        for _ in range(np.random.randint(0, 101)):
            while True:
                x = np.random.randint(0, self.grid.shape[0])
                y = np.random.randint(0, self.grid.shape[1])
                if (x, y) not in (self.start, self.goal) and self.grid[x, y] != -100:
                    self.grid[x, y] = -100
                    break
        if fixed_start_goal:
            self.start, self.goal = (0, 0), (29, 29)
        else:
            if start and goal:
                self.start, self.goal = start, goal
            else:
                while True:
                    s = (np.random.randint(self.grid.shape[0]),
                         np.random.randint(self.grid.shape[1]))
                    g = (np.random.randint(self.grid.shape[0]),
                         np.random.randint(self.grid.shape[1]))
                    if self.grid[s] != -100 and self.grid[g] != -100 and s != g:
                        self.start, self.goal = s, g
                        break
        self.current_position = self.start
        self.done = False
        self.visited_positions = {self.start}
        return self._get_state()

    def _get_state(self):
        x, y = self.current_position
        rel = [self.goal[0] - x, self.goal[1] - y, self.goal[0], self.goal[1]]
        neigh = []
        for dx, dy in [(-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1)]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.grid.shape[0] and 0 <= ny < self.grid.shape[1]:
                neigh.append(np.hypot(dx, dy) if self.grid[nx, ny] == -100 else 100)
            else:
                neigh.append(-100)
        return np.array(rel + neigh, dtype=np.float32)

    def step(self, action):
        dirs = [(-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1)]
        dx, dy = dirs[action]
        x, y = self.current_position
        new = (x + dx, y + dy)
        reward = -1
        if 0 <= new[0] < self.grid.shape[0] and 0 <= new[1] < self.grid.shape[1]:
            self.current_position = new
            v = self.grid[new]
            reward += (-10 if v == -100 else v * 0.1)
            reward += -7 if new in self.visited_positions else 0
            self.visited_positions.add(new)
        else:
            reward -= 10

        old_d = np.hypot(self.goal[0] - x, self.goal[1] - y)
        new_d = np.hypot(self.goal[0] - self.current_position[0],
                         self.goal[1] - self.current_position[1])
        reward += -3 if new_d > old_d else 1

        if self.current_position == self.goal:
            self.done = True
            reward += 15
        return self._get_state(), reward, self.done, {}

    def render(self):
        if self.current_position is None:
            raise ValueError("请先调用 reset()")
        g = self.grid.copy()
        x, y = self.current_position
        g[x, y] = -999
        return g

class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim, n_latent_var):
        super().__init__()
        self.action_layer = nn.Sequential(
            nn.Linear(state_dim, n_latent_var), nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var), nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var), nn.Tanh(),
            nn.Linear(n_latent_var, action_dim), nn.Softmax(dim=-1)
        )
        self.value_layer = nn.Sequential(
            nn.Linear(state_dim, n_latent_var), nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var), nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var), nn.Tanh(),
            nn.Linear(n_latent_var, 1)
        )

    def act(self, state):
        s = torch.from_numpy(state).float().to(device)
        probs = self.action_layer(s)
        return Categorical(probs).sample().item()


def visualize_path(model_path, raster_path, start, goal, episode, max_steps=300):
    env = GridEnvironment(raster_path, start, goal)
    model = ActorCritic(state_dim=12, action_dim=8, n_latent_var=128).to(device)
    model.load_state_dict(torch.load(model_path))
    model.eval()


    path = [start]
    state = env.reset(start, goal)
    done, steps = False, 0
    while not done and steps < max_steps:
        a = model.act(state)
        state, _, done, _ = env.step(a)
        path.append(env.current_position)
        steps += 1

    smoothed_path = smooth_with_cubic_bezier(path, env.original_grid)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8))


    ax1.set_title(f"原始路径 (点数: {len(path)})")
    ax1.imshow(env.original_grid, cmap='viridis')
    if len(path) > 1:
        y, x = zip(*path)
        ax1.plot(x, y, 'b-', linewidth=1, alpha=0.5)
    ax1.scatter(start[1], start[0], c='red', marker='o', s=100, label='起点')
    ax1.scatter(goal[1], goal[0], c='black', marker='s', s=100, label='终点')
    ax1.legend()

    ax2.set_title(f"三次Bézier平滑 (点数: {len(smoothed_path)})")
    ax2.imshow(env.original_grid, cmap='viridis')
    if len(smoothed_path) > 1:
        sy, sx = zip(*smoothed_path)
        ax2.plot(sx, sy, 'r-', linewidth=3)

        control_points = extract_key_points(path, env.original_grid)
        cy, cx = zip(*control_points)

    ax2.scatter(start[1], start[0], c='red', marker='o', s=100)
    ax2.scatter(goal[1], goal[0], c='black', marker='s', s=100)

    plt.savefig(f'path_cubic_bezier_{episode}.png', dpi=150, bbox_inches='tight')
    plt.close()


    def path_length(points):
        return sum(
            math.hypot(p2[0] - p1[0], p2[1] - p1[1])
            for p1, p2 in zip(points[:-1], points[1:])
        )

    print(f"第{episode}次结果 | 原始: {len(path)}点/{path_length(path):.1f}m → "
          f"平滑: {len(smoothed_path)}点/{path_length(smoothed_path):.1f}m "
          f"(减少{100 * (1 - len(smoothed_path) / len(path)):.1f}%)")

def main():
    model_path = "dppo_model_episode_200000.pth"
    raster_path = "128.tif"
    start = (80, 1)
    goal = (121, 120)
    for i in range(1, 11):
        print(f"\n正在进行第{i}次路径规划...")
        try:
            visualize_path(model_path, raster_path, start, goal, i)
        except Exception as e:
            print(f"第{i}次处理出错: {str(e)}")

if __name__ == "__main__":
    main()
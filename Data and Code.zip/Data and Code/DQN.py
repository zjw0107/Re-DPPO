import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
from collections import deque
from osgeo import gdal
import os
import pandas as pd


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class GridEnvironment:
    def __init__(self, raster_path, start, goal):
        self.raster_path = raster_path
        self.grid = self._load_raster()
        self.start = start
        self.goal = goal
        self.current_position = None
        self.done = False
        self.visited_positions = set()
        self.original_grid = self.grid.copy()

    def _load_raster(self):
        dataset = gdal.Open(self.raster_path)
        band = dataset.GetRasterBand(1)
        return band.ReadAsArray()

    def reset(self, fixed_start_goal=False):

        self.grid = self.original_grid.copy()

        num_obstacles = np.random.randint(0, 101)
        for _ in range(num_obstacles):
            while True:
                x = np.random.randint(0, self.grid.shape[0])
                y = np.random.randint(0, self.grid.shape[1])

                if (x, y) != self.start and (x, y) != self.goal and self.grid[x, y] != -100:
                    self.grid[x, y] = -100
                    break

        if fixed_start_goal:
            self.start = (0, 0)
            self.goal = (29, 29)
        else:
            while True:
                self.start = (np.random.randint(0, self.grid.shape[0]), np.random.randint(0, self.grid.shape[1]))
                self.goal = (np.random.randint(0, self.grid.shape[0]), np.random.randint(0, self.grid.shape[1]))
                if (self.grid[self.start] != -100 and self.grid[self.goal] != -100 and self.start != self.goal):
                    break
        self.current_position = self.start
        self.done = False
        self.visited_positions.clear()
        self.visited_positions.add(self.start)
        return self._get_state()

    def _get_state(self):
        x, y = self.current_position
        start_rel_x = self.start[0] - x
        start_rel_y = self.start[1] - y
        goal_rel_x = self.goal[0] - x
        goal_rel_y = self.goal[1] - y
        neighbor_states = []
        for i in range(x - 1, x + 2):
            for j in range(y - 1, y + 2):
                if i == x and j == y:
                    continue
                if 0 <= i < self.grid.shape[0] and 0 <= j < self.grid.shape[1]:
                    if self.grid[i][j] == -100:
                        distance = np.sqrt((i - x) ** 2 + (j - y) ** 2)
                        neighbor_states.append(distance)
                    else:
                        neighbor_states.append(100)
                else:
                    neighbor_states.append(-100)
        return np.array([start_rel_x, start_rel_y, goal_rel_x, goal_rel_y] + neighbor_states, dtype=np.float32)

    def step(self, action):
        direction_map = [(-1, 0), (-1, 1), (0, 1), (1, 1),
                         (1, 0), (1, -1), (0, -1), (-1, -1)]
        dx, dy = direction_map[action]
        x, y = self.current_position
        new_position = (x + dx, y + dy)
        reward = -1
        if 0 <= new_position[0] < self.grid.shape[0] and 0 <= new_position[1] < self.grid.shape[1]:
            self.current_position = new_position
            grid_value = self.grid[self.current_position]
            if grid_value == -100:
                reward += -10
            else:
                reward += grid_value * 0.1
            if new_position in self.visited_positions:
                reward -= 7
            else:
                self.visited_positions.add(new_position)
        else:
            reward += -10
        old_distance = np.sqrt((self.goal[0] - x) ** 2 + (self.goal[1] - y) ** 2)
        new_distance = np.sqrt((self.goal[0] - self.current_position[0]) ** 2 + (self.goal[1] - self.current_position[1]) ** 2)
        reward += -3 if new_distance > old_distance else 1
        if self.current_position == self.goal:
            self.done = True
            reward += 15
        return self._get_state(), reward, self.done, {}

class DQN(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(DQN, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, action_dim)
        )

    def forward(self, x):
        return self.fc(x)


class DQNAgent:
    def __init__(self, state_dim, action_dim, lr, gamma, epsilon, epsilon_decay,
                 epsilon_min, memory_size, batch_size, target_update):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min
        self.batch_size = batch_size
        self.target_update = target_update
        self.memory = deque(maxlen=memory_size)
        self.policy_net = DQN(state_dim, action_dim).to(device)
        self.target_net = DQN(state_dim, action_dim).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=lr)
        self.loss_fn = nn.MSELoss()

    def select_action(self, state):
        if np.random.rand() < self.epsilon:
            return np.random.randint(self.action_dim)
        state = torch.FloatTensor(state).to(device)
        with torch.no_grad():
            return torch.argmax(self.policy_net(state)).item()

    def store_experience(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))

    def train(self):
        if len(self.memory) < self.batch_size:
            return
        batch = random.sample(self.memory, self.batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        states = torch.FloatTensor(states).to(device)
        actions = torch.LongTensor(actions).to(device)
        rewards = torch.FloatTensor(rewards).to(device)
        next_states = torch.FloatTensor(next_states).to(device)
        dones = torch.FloatTensor(dones).to(device)

        q_values = self.policy_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)
        next_q_values = self.target_net(next_states).max(1)[0].detach()
        target_q_values = rewards + self.gamma * next_q_values * (1 - dones)
        loss = self.loss_fn(q_values, target_q_values)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

    def update_target_network(self):
        self.target_net.load_state_dict(self.policy_net.state_dict())

def train_dqn():
    raster_path = "128.tif"
    env = GridEnvironment(raster_path, (0, 0), (29, 29))
    state_dim = 12
    action_dim = 8
    agent = DQNAgent(state_dim, action_dim, lr=0.0001,
                     gamma=0.99, epsilon=1.0, epsilon_decay=0.995,
                     epsilon_min=0.1, memory_size=1000000, batch_size=64, target_update=10)
    episodes = 300000
    max_steps = 1000

    rewards_history = []

    checkpoint_path = ""
    if os.path.exists(checkpoint_path):
        agent.policy_net.load_state_dict(torch.load(checkpoint_path))
        agent.target_net.load_state_dict(agent.policy_net.state_dict())
        print(f"Loaded model from {checkpoint_path}")
    else:
        print("No checkpoint found, starting from scratch.")

    start_episode = 1

    for episode in range(start_episode, episodes):

        if episode <= 1:
            state = env.reset(fixed_start_goal=True)
        else:
            state = env.reset(fixed_start_goal=False)
        total_reward = 0
        step_count = 0

        while True:
            action = agent.select_action(state)
            next_state, reward, done, _ = env.step(action)
            agent.store_experience(state, action, reward, next_state, done)
            agent.train()
            state = next_state
            total_reward += reward
            step_count += 1
            if done or step_count >= max_steps:
                break

        rewards_history.append(total_reward)
        agent.epsilon = max(agent.epsilon * agent.epsilon_decay, agent.epsilon_min)

        if episode % agent.target_update == 0:
            agent.update_target_network()

        print(f"Episode {episode}, Total Reward: {total_reward}, Steps: {step_count}")


        if (episode + 1) % 2000 == 0:

            model_save_path = f"DQN_model_episode_{episode+1}.pth"
            torch.save(agent.policy_net.state_dict(), model_save_path)
            print(f"Saved policy network to {model_save_path}")


            df_rewards = pd.DataFrame({
                'Episode': list(range(start_episode, episode + 1)),
                'Reward': rewards_history
            })
            excel_save_path = f"DQN_{episode+1}.xlsx"
            df_rewards.to_excel(excel_save_path, index=False)
            print(f"Saved rewards to {excel_save_path}")


    print("\n" + "=" * 50)

    print("=" * 50)

if __name__ == '__main__':
    train_dqn()

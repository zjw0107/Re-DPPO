import torch
import torch.nn as nn
from torch.distributions import Categorical
import numpy as np
from osgeo import gdal
import math
import os
import pandas as pd
import random


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class GridEnvironment:
    def __init__(self, raster_path, start, goal):
        self.raster_path = raster_path
        self.grid = self._load_raster()
        self.start = start
        self.goal = goal
        self.current_position = None
        self.done = False
        self.visited_positions = set()
        self.original_grid = self.grid.copy()

    def _load_raster(self):
        dataset = gdal.Open(self.raster_path)
        band = dataset.GetRasterBand(1)
        return band.ReadAsArray()

    def reset(self, fixed_start_goal=False):

        self.grid = self.original_grid.copy()

        num_obstacles = np.random.randint(0, 101)
        for _ in range(num_obstacles):
            while True:
                x = np.random.randint(0, self.grid.shape[0])
                y = np.random.randint(0, self.grid.shape[1])

                if (x, y) != self.start and (x, y) != self.goal and self.grid[x, y] != -100:
                    self.grid[x, y] = -100
                    break

        if fixed_start_goal:
            self.start = (0, 0)
            self.goal = (29, 29)
        else:
            while True:
                self.start = (np.random.randint(0, self.grid.shape[0]), np.random.randint(0, self.grid.shape[1]))
                self.goal = (np.random.randint(0, self.grid.shape[0]), np.random.randint(0, self.grid.shape[1]))
                if (self.grid[self.start] != -100 and self.grid[self.goal] != -100 and self.start != self.goal):
                    break
        self.current_position = self.start
        self.done = False
        self.visited_positions.clear()
        self.visited_positions.add(self.start)
        return self._get_state()

    def _get_state(self):
        x, y = self.current_position
        start_rel_x = self.start[0] - x
        start_rel_y = self.start[1] - y
        goal_rel_x = self.goal[0] - x
        goal_rel_y = self.goal[1] - y
        neighbor_states = []
        for i in range(x - 1, x + 2):
            for j in range(y - 1, y + 2):
                if i == x and j == y:
                    continue
                if 0 <= i < self.grid.shape[0] and 0 <= j < self.grid.shape[1]:
                    if self.grid[i][j] == -100:
                        distance = np.sqrt((i - x) ** 2 + (j - y) ** 2)
                        neighbor_states.append(distance)
                    else:
                        neighbor_states.append(100)
                else:
                    neighbor_states.append(-100)
        return np.array([start_rel_x, start_rel_y, goal_rel_x, goal_rel_y] + neighbor_states, dtype=np.float32)

    def step(self, action):
        direction_map = [(-1, 0), (-1, 1), (0, 1), (1, 1),
                         (1, 0), (1, -1), (0, -1), (-1, -1)]
        dx, dy = direction_map[action]
        x, y = self.current_position
        new_position = (x + dx, y + dy)
        reward = -10
        if 0 <= new_position[0] < self.grid.shape[0] and 0 <= new_position[1] < self.grid.shape[1]:
            self.current_position = new_position
            grid_value = self.grid[self.current_position]
            if grid_value == -100:
                reward += -100
            else:
                reward += grid_value
            if new_position in self.visited_positions:
                reward -= -50
            else:
                self.visited_positions.add(new_position)
        else:
            reward += -100
        old_distance = np.sqrt((self.goal[0] - x) ** 2 + (self.goal[1] - y) ** 2)
        new_distance = np.sqrt((self.goal[0] - self.current_position[0]) ** 2 + (self.goal[1] - self.current_position[1]) ** 2)
        reward += -10 if new_distance > old_distance else 5
        if self.current_position == self.goal:
            self.done = True
            reward += 150
        return self._get_state(), reward, self.done, {}

    def render(self):
        grid_copy = self.grid.copy()
        x, y = self.current_position
        grid_copy[x, y] = -999
        print(grid_copy)

class Memory:
    def __init__(self):
        self.actions = []
        self.states = []
        self.logprobs = []
        self.rewards = []
        self.is_terminals = []

    def clear_memory(self):
        del self.actions[:]
        del self.states[:]
        del self.logprobs[:]
        del self.rewards[:]
        del self.is_terminals[:]

class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity

        self.buffer = {}

        self.queue = []
        self.size = 0

    def _get_neighbor_hash(self, state):

        neighbor_features = state[4:12]

        discrete_neighbors = tuple(1 if f < 100 else 0 for f in neighbor_features)
        return hash(discrete_neighbors)

    def push(self, state, action, reward, goal_rel_x, goal_rel_y, goal_x, goal_y):

        if reward < -1:
            return
        neighbor_hash = self._get_neighbor_hash(state)
        composite_key = (goal_rel_x, goal_rel_y, goal_x, goal_y, neighbor_hash)
        if composite_key in self.buffer:
            for transition in self.buffer[composite_key]:
                if np.array_equal(transition[0], state) and transition[1] == action:
                    return
        else:
            self.buffer[composite_key] = []


            if self.size >= self.capacity:
                oldest_key, index = self.queue.pop(0)
                self.buffer[oldest_key].pop(0)
                if len(self.buffer[oldest_key]) == 0:
                    del self.buffer[oldest_key]
                self.size -= 1

            transition = (state, action, reward,
                          goal_rel_x, goal_rel_y,
                          goal_x, goal_y,
                          state[4:12].copy())
            self.buffer[composite_key].append(transition)
            self.queue.append((composite_key, len(self.buffer[composite_key]) - 1))
            self.size += 1

    def sample(self, current_state, goal_rel_x, goal_rel_y, goal_x, goal_y, batch_size):

        current_neighbors = current_state[4:12]

        candidate_keys = []
        base_hash = self._get_neighbor_hash(current_state)
        candidate_keys.append((goal_rel_x, goal_rel_y, goal_x, goal_y, base_hash))

        for delta in [-1, 1]:
            perturbed_neighbors = [max(0, x + delta) for x in current_neighbors]
            candidate_keys.append((goal_rel_x, goal_rel_y, goal_x, goal_y,
                                   hash(tuple(perturbed_neighbors))))

        candidates = []
        for key in candidate_keys:
            if key in self.buffer:
                for transition in self.buffer[key]:

                    if np.array_equal(transition[7], current_neighbors):
                        candidates.append(transition)

        if candidates:

            best_exp = max(candidates,
                           key=lambda x: x[2] + 0.1 * x[-1])
            return [best_exp]
        return []
    def __len__(self):
        return self.size

class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim, n_latent_var):
        super(ActorCritic, self).__init__()
        self.action_layer = nn.Sequential(
            nn.Linear(state_dim, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, action_dim),
            nn.Softmax(dim=-1)
        )
        self.value_layer = nn.Sequential(
            nn.Linear(state_dim, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, n_latent_var),
            nn.Tanh(),
            nn.Linear(n_latent_var, 1)
        )
    def forward(self):
        raise NotImplementedError
    def act(self, state, memory):
        state_tensor = torch.from_numpy(state).float().to(device)
        action_probs = self.action_layer(state_tensor)
        dist = Categorical(action_probs)
        action = dist.sample()
        memory.states.append(state_tensor)
        memory.actions.append(action)
        memory.logprobs.append(dist.log_prob(action))
        return action.item()
    def evaluate(self, state, action):
        action_probs = self.action_layer(state)
        dist = Categorical(action_probs)
        action_logprobs = dist.log_prob(action)
        dist_entropy = dist.entropy()
        state_value = self.value_layer(state)
        return action_logprobs, torch.squeeze(state_value), dist_entropy


class DPPO:
    def __init__(self, state_dim, action_dim, n_latent_var, lr, betas, gamma, K_epochs, eps_clip):
        self.lr = lr
        self.betas = betas
        self.gamma = gamma
        self.eps_clip = eps_clip
        self.K_epochs = K_epochs

        self.policy = ActorCritic(state_dim, action_dim, n_latent_var).to(device)
        self.optimizer = torch.optim.Adam(self.policy.parameters(), lr=lr, betas=betas)
        self.policy_old = ActorCritic(state_dim, action_dim, n_latent_var).to(device)
        self.policy_old.load_state_dict(self.policy.state_dict())
        self.MseLoss = nn.MSELoss()
    def update(self, memory):
        rewards = []
        discounted_reward = 0
        for reward, is_terminal in zip(reversed(memory.rewards), reversed(memory.is_terminals)):
            if is_terminal:
                discounted_reward = 0
            discounted_reward = reward + (self.gamma * discounted_reward)
            rewards.insert(0, discounted_reward)
        rewards = torch.tensor(rewards, dtype=torch.float32).to(device)
        mean_reward = rewards.mean()
        std_reward = rewards.std()
        if std_reward > 0:
            rewards = (rewards - mean_reward) / (std_reward + 1e-5)
        else:
            rewards = rewards - mean_reward
        old_states = torch.stack(memory.states).to(device).detach()
        old_actions = torch.stack(memory.actions).to(device).detach()
        old_logprobs = torch.stack(memory.logprobs).to(device).detach()
        for _ in range(self.K_epochs):
            logprobs, state_values, dist_entropy = self.policy.evaluate(old_states, old_actions)
            ratios = torch.exp(logprobs - old_logprobs.detach())
            advantages = rewards - state_values.detach()
            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
            loss = -torch.min(surr1, surr2).mean() + 0.5 * self.MseLoss(state_values, rewards) - 0.05 * dist_entropy.mean()
            self.optimizer.zero_grad()
            loss.mean().backward()
            torch.nn.utils.clip_grad_norm_(self.policy.parameters(), max_norm=1.0)
            self.optimizer.step()
        self.policy_old.load_state_dict(self.policy.state_dict())


def main():
    raster_path = "128.tif"

    dummy_start = (0, 0)
    dummy_goal = (16, 16)
    num_agents = 8

    envs = [GridEnvironment(raster_path, dummy_start, dummy_goal) for _ in range(num_agents)]
    state_dim = 12
    action_dim = 8
    n_latent_var = 128

    global_memory = Memory()

    replay_buffer = ReplayBuffer(capacity=100000000)

    dppo = DPPO(state_dim, action_dim, n_latent_var, lr=0.0001, betas=(0.9, 0.999),
                gamma=0.99, K_epochs=2, eps_clip=0.15)
    max_episodes = 100000
    max_timesteps = 150
    checkpoint_path = ""
    if os.path.exists(checkpoint_path):
        dppo.policy.load_state_dict(torch.load(checkpoint_path))
        dppo.policy_old.load_state_dict(dppo.policy.state_dict())
        print(f"Loaded model from {checkpoint_path}")
    else:
        print("No checkpoint found, starting from scratch.")
    rewards_df = pd.DataFrame(columns=["Episode", "Average Reward"])
    start_episode = 1


    initial_prob = 0.9
    decay_rate = 0.0001
    stop_exploration_episode = 100000

    for i_episode in range(start_episode, max_episodes + 1):
        episode_rewards = []

        if i_episode <= stop_exploration_episode:
            current_prob = initial_prob * math.exp(-decay_rate * i_episode)
        else:
            current_prob = 0

        for agent in range(num_agents):

            state = envs[agent].reset(fixed_start_goal=False)
            total_reward = 0
            local_memory = Memory()
            for t in range(max_timesteps):

                current_pos = envs[agent].current_position
                current_goal = envs[agent].goal
                rel_dx = current_goal[0] - current_pos[0]
                rel_dy = current_goal[1] - current_pos[1]
                goal_x, goal_y = current_goal

                if random.random() < current_prob:

                    similar_transitions = replay_buffer.sample(state, rel_dx, rel_dy, goal_x, goal_y, batch_size=1)


                    if len(similar_transitions) > 0 and np.random.rand() < 0.9:
                        proposed_action = similar_transitions[0][1]

                        action = proposed_action
                        state_tensor = torch.from_numpy(state).float().to(device)
                        with torch.no_grad():
                            action_probs = dppo.policy_old.action_layer(state_tensor)
                            dist = Categorical(action_probs)
                            logprob = dist.log_prob(torch.tensor(action).to(device))
                        local_memory.states.append(state_tensor)
                        local_memory.actions.append(torch.tensor(action).to(device))
                        local_memory.logprobs.append(logprob)
                    else:

                        action = dppo.policy_old.act(state, local_memory)
                else:

                    action = dppo.policy_old.act(state, local_memory)


                old_position = envs[agent].current_position
                next_state, reward, done, _ = envs[agent].step(action)
                total_reward += reward


                replay_buffer.push(state, action, reward,
                                   current_goal[0] - old_position[0],
                                   current_goal[1] - old_position[1],
                                   current_goal[0], current_goal[1])
                local_memory.rewards.append(reward)
                local_memory.is_terminals.append(done)
                state = next_state
                if done:
                    break

            global_memory.states.extend(local_memory.states)
            global_memory.actions.extend(local_memory.actions)
            global_memory.logprobs.extend(local_memory.logprobs)
            global_memory.rewards.extend(local_memory.rewards)
            global_memory.is_terminals.extend(local_memory.is_terminals)
            episode_rewards.append(total_reward)

        dppo.update(global_memory)
        global_memory.clear_memory()
        avg_reward = np.mean(episode_rewards)
        print(f"Episode {i_episode} completed. Average Reward: {avg_reward:.2f}")
        new_row = pd.DataFrame({"Episode": [i_episode], "Average Reward": [avg_reward]})
        rewards_df = pd.concat([rewards_df, new_row], ignore_index=True)
        if i_episode % 2000 == 0:
            torch.save(dppo.policy.state_dict(), f"dppo_model_episode_{i_episode}.pth")
            rewards_df.to_excel(f"dppo_{i_episode}.xlsx", index=False)


    print("\n" + "=" * 50)
    print("=" * 50)
print("Training finished!")
if __name__ == "__main__":
    main()
